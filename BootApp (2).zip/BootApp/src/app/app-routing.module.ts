import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { PageComponent } from './page/page.component';
import { MenuComponent } from './menu/menu.component';
import { BookComponent } from './book/book.component';
import { PaymentComponent } from './payment/payment.component';

const routes: Routes = [{path:'', component: HomeComponent ,children :[ {path :'' , component : MenuComponent},
                                                                        {path :'page' , component : PageComponent},
                                                                        {path :'home' , component : HomeComponent},
                                                                        {path :'payment' , component : PaymentComponent},
                                                                        {path :'book' , component : BookComponent}]}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
